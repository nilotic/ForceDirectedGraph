# ForceDirectedGraphSwift

[![CI Status](http://img.shields.io/travis/Den/ForceDirectedGraphSwift.svg?style=flat)](https://travis-ci.org/Den/ForceDirectedGraphSwift)
[![Version](https://img.shields.io/cocoapods/v/ForceDirectedGraphSwift.svg?style=flat)](http://cocoapods.org/pods/ForceDirectedGraphSwift)
[![License](https://img.shields.io/cocoapods/l/ForceDirectedGraphSwift.svg?style=flat)](http://cocoapods.org/pods/ForceDirectedGraphSwift)
[![Platform](https://img.shields.io/cocoapods/p/ForceDirectedGraphSwift.svg?style=flat)](http://cocoapods.org/pods/ForceDirectedGraphSwift)

## Example

To run the example project, clone the repo, and run `pod install` from the Example directory first.

## Requirements

## Installation

ForceDirectedGraphSwift is available through [CocoaPods](http://cocoapods.org). To install
it, simply add the following line to your Podfile:

```ruby
pod "ForceDirectedGraphSwift"
```

## Author

Den, den@dailyhotel.com

## License

ForceDirectedGraphSwift is available under the MIT license. See the LICENSE file for more info.
